# Telegram-Name-Updating

一个面向 VPS 常驻运行场景的 Telegram 资料自动更新脚本。默认每 `30` 秒刷新一次 `last_name`，并根据当前时间随机生成不同样式；可选同步固定的 `first_name` 与 `username`。

## 当前版本解决了什么

- 兼容最新 `emoji 2.x` 与 `Telethon 1.42.x`
- 不再把 `TG_API_ID`、`TG_API_HASH`、代理、手机号等信息硬编码在代码里
- 首次运行可通过主程序交互生成 `config.local.json`
- 程序后续直接读取配置文件运行
- 首次未授权时会自动提示输入验证码与二次验证密码
- 不再使用“1 秒轮询 + 秒值判断”，改为精确的间隔调度
- 增强了日志、`FloodWait` 处理、优雅退出与 `dry-run`

## 运行环境

- Python `3.10+`
- 首次登录需要交互式输入 Telegram 验证码
- 如果账号开启了二次验证，首次登录还会提示输入密码

## 安装

```bash
git clone https://github.com/xyou365/Telegram-Name-Updating.git
cd Telegram-Name-Updating
python -m venv .venv
.venv/bin/pip install -r requirements.txt
```

Windows 下请把最后一行替换为：

```powershell
.\.venv\Scripts\python -m pip install -r requirements.txt
```

## 初始化配置

首次运行时，如果当前目录下不存在 `config.local.json`，主程序会自动进入初始化向导并询问：

- `TG_API_ID`
- `TG_API_HASH`
- Telegram 手机号
- 代理信息
- 时区
- 更新间隔
- 固定 `first_name` / `username`
- 是否将二次验证密码保存到配置文件

你也可以显式执行初始化命令：

```bash
python tg_username_update.py --init-config
```

Windows：

```powershell
.\.venv\Scripts\python tg_username_update.py --init-config
```

## 配置文件说明

程序默认读取根目录下的 `config.local.json`。这是一个本地配置文件，已被 `.gitignore` 忽略，不会进入版本控制。

示例结构：

```json
{
  "api_id": 123456,
  "api_hash": "your_api_hash",
  "phone_number": "+8613812345678",
  "timezone": "Asia/Shanghai",
  "session_name": "api_auth",
  "update_interval": 30,
  "first_name": null,
  "username": null,
  "last_name_prefix": "",
  "last_name_suffix": "",
  "proxy_type": "socks5",
  "proxy_host": "127.0.0.1",
  "proxy_port": 7897,
  "proxy_username": null,
  "proxy_password": null,
  "proxy_rdns": true,
  "two_step_password": null,
  "run_on_start": true,
  "reset_last_name_on_exit": false,
  "dry_run": false,
  "log_level": "INFO"
}
```

说明：

- `验证码` 是一次性凭据，不会写入配置文件
- `two_step_password` 支持可选保存，但默认不建议保存
- `session_name` 对应 Telethon 的 `.session` 文件名前缀

## 运行

```bash
python tg_username_update.py
```

Windows：

```powershell
.\.venv\Scripts\python tg_username_update.py
```

如果配置文件不在默认路径，可以指定：

```bash
python tg_username_update.py --config /path/to/your-config.json
```

## systemd 示例

```ini
[Unit]
Description=Telegram Name Updating
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/Telegram-Name-Updating
ExecStart=/opt/Telegram-Name-Updating/.venv/bin/python /opt/Telegram-Name-Updating/tg_username_update.py --config /opt/Telegram-Name-Updating/config.local.json
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

## 注意事项

- 高频修改资料有触发 Telegram 限流或风控的风险，建议优先用自己的测试号验证。
- `username` 与 `last_name` 不同，它必须全局唯一，因此这里只支持“固定目标用户名”的同步，不建议做每 30 秒变化一次的动态用户名。
- 首次跑通后会生成 `api_auth.session`（或你自定义的 session 文件名），请自行妥善保存。
- 如果你所在网络无法直连 Telegram，请准备可用的 SOCKS5 / HTTP 代理，Telethon 1.42 官方文档支持通过 `proxy=` 参数接入代理。

## Windows 开机自动运行

当前仓库提供了启动脚本 [run_telegram_name_updating.ps1](F:/Project/Telegram-Name-Updating/auto-start/run_telegram_name_updating.ps1) 和登录后延迟启动脚本 [run_telegram_name_updating_startup.cmd](F:/Project/Telegram-Name-Updating/auto-start/run_telegram_name_updating_startup.cmd)。

推荐使用“任务计划程序”或“启动文件夹”设置为“用户登录后延迟启动”，原因是很多本地代理会在登录后才可用。脚本会：

- 自动创建 `logs/telegram-name-updating.log`
- 检查是否已有同一实例在运行，避免重复启动
- 后台拉起主程序并读取 `config.local.json`
